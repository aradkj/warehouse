"""Idempotent RabbitMQ event consumer wrapper.

Receives RabbitMQ messages, validates the event envelope, enforces consumer inbox
idempotency inside PostgreSQL transactions, executes business handlers, and commits state
BEFORE acknowledging the RabbitMQ message.
"""

from __future__ import annotations

import json
import logging
import uuid
from datetime import UTC, datetime
from typing import Any, Awaitable, Callable

import aio_pika

from shared.application.context import ActorType, RequestContext
from shared.domain.identifiers import TenantId
from shared.infrastructure.db.session import Database
from shared.infrastructure.messaging.inbox import SqlAlchemyInboxRepository

logger = logging.getLogger(__name__)

HandlerFunc = Callable[[dict[str, Any], RequestContext], Awaitable[Any]]


class IdempotentConsumer:
    """Wrapper that guarantees idempotent, tenant-safe message processing."""

    __slots__ = ("_consumer_name", "_database", "_handlers")

    def __init__(self, database: Database, consumer_name: str) -> None:
        self._database = database
        self._consumer_name = consumer_name
        self._handlers: dict[str, HandlerFunc] = {}

    def register_handler(self, event_type: str, handler: HandlerFunc) -> None:
        """Register a handler callback for a specific event_type."""
        self._handlers[event_type] = handler

    async def process_message(self, message: aio_pika.abc.AbstractIncomingMessage) -> None:
        """Process an incoming RabbitMQ message idempotently."""
        async with message.process(requeue=False, ignore_processed=True):
            try:
                body = json.loads(message.body.decode("utf-8"))
            except Exception as exc:
                logger.error(
                    "Consumer %s: Malformed JSON payload received: %s",
                    self._consumer_name,
                    exc,
                )
                # Reject poison message to DLQ (process context with requeue=False sends to DLQ)
                return

            event_id = body.get("event_id") or message.message_id
            event_type = body.get("event_type")
            tenant_id_str = body.get("tenant_id")
            correlation_id = body.get("correlation_id") or str(uuid.uuid4())
            causation_id = body.get("causation_id")

            if not event_id or not event_type or not tenant_id_str:
                logger.error(
                    "Consumer %s: Missing required envelope fields in event: %s",
                    self._consumer_name,
                    body,
                )
                return

            try:
                tenant_uuid = uuid.UUID(str(tenant_id_str))
            except ValueError:
                logger.error(
                    "Consumer %s: Invalid tenant_id UUID format: %s",
                    self._consumer_name,
                    tenant_id_str,
                )
                return

            handler = self._handlers.get(event_type)
            if handler is None:
                logger.debug(
                    "Consumer %s: No handler registered for event_type %s",
                    self._consumer_name,
                    event_type,
                )
                return

            context = RequestContext(
                tenant_id=TenantId(tenant_uuid),
                actor_id=f"consumer:{self._consumer_name}",
                actor_type=ActorType.SYSTEM,
                correlation_id=correlation_id,
                causation_id=causation_id,
                received_at=datetime.now(UTC),
            )

            now = datetime.now(UTC)

            # Idempotent database execution
            async with self._database.new_scope() as scope:
                inbox_repo = SqlAlchemyInboxRepository(scope.session)
                should_proceed = await inbox_repo.claim_for_processing(
                    message_id=str(event_id),
                    consumer_name=self._consumer_name,
                    tenant_id=tenant_uuid,
                    event_type=event_type,
                    now=now,
                )

                if not should_proceed:
                    logger.info(
                        "Consumer %s: Message %s (%s) already processed; skipping.",
                        self._consumer_name,
                        event_id,
                        event_type,
                    )
                    await scope.commit()
                    return

                try:
                    await handler(body.get("payload", {}), context)
                    await inbox_repo.mark_processed(
                        message_id=str(event_id),
                        consumer_name=self._consumer_name,
                        now=datetime.now(UTC),
                    )
                    await scope.commit()
                    logger.info(
                        "Consumer %s: Successfully processed message %s (%s)",
                        self._consumer_name,
                        event_id,
                        event_type,
                    )
                except Exception as exc:
                    logger.error(
                        "Consumer %s: Processing failed for message %s (%s): %s",
                        self._consumer_name,
                        event_id,
                        event_type,
                        exc,
                        exc_info=True,
                    )
                    await scope.rollback()
                    # Record failure in a separate transaction
                    async with self._database.new_scope() as fail_scope:
                        fail_inbox = SqlAlchemyInboxRepository(fail_scope.session)
                        await fail_inbox.record_failure(
                            message_id=str(event_id),
                            consumer_name=self._consumer_name,
                            error=str(exc),
                            now=datetime.now(UTC),
                        )
                        await fail_scope.commit()
                    raise


__all__ = ["HandlerFunc", "IdempotentConsumer"]
