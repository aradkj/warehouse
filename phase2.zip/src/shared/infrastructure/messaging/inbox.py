"""Consumer Inbox implementation for message-level idempotency.

Prevents duplicate execution when the same message is delivered more than once to a consumer.
Each consumer uses its own consumer_name so multiple distinct services can process the same message once each.
"""

from __future__ import annotations

import logging
import uuid
from datetime import UTC, datetime
from typing import Any

from sqlalchemy import select, update
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.ext.asyncio import AsyncSession

from shared.infrastructure.db.tables import inbox_messages

logger = logging.getLogger(__name__)


class SqlAlchemyInboxRepository:
    """Inbox repository adapter enforcing consumer idempotency."""

    __slots__ = ("_session",)

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def is_already_processed(
        self, *, message_id: str, consumer_name: str
    ) -> bool:
        """Return True if message has already been successfully processed by consumer_name."""
        stmt = select(inbox_messages.c.status).where(
            inbox_messages.c.message_id == message_id,
            inbox_messages.c.consumer_name == consumer_name,
        )
        status = (await self._session.execute(stmt)).scalar_one_or_none()
        return status == "PROCESSED"

    async def claim_for_processing(
        self,
        *,
        message_id: str,
        consumer_name: str,
        tenant_id: uuid.UUID,
        event_type: str,
        now: datetime,
    ) -> bool:
        """Claim a message for processing.

        Returns True if processing should proceed.
        Returns False if already PROCESSED.
        """
        # ON CONFLICT DO NOTHING on (message_id, consumer_name)
        stmt = (
            pg_insert(inbox_messages)
            .values(
                id=uuid.uuid4(),
                message_id=message_id,
                consumer_name=consumer_name,
                tenant_id=tenant_id,
                event_type=event_type,
                status="RECEIVED",
                attempt_count=1,
                received_at=now,
            )
            .on_conflict_do_nothing(index_elements=["message_id", "consumer_name"])
            .returning(*inbox_messages.c)
        )
        row = (await self._session.execute(stmt)).mappings().first()
        if row is not None:
            return True

        # Conflict occurred: check current status
        check_stmt = select(inbox_messages).where(
            inbox_messages.c.message_id == message_id,
            inbox_messages.c.consumer_name == consumer_name,
        )
        existing = (await self._session.execute(check_stmt)).mappings().first()
        if existing is None:  # pragma: no cover
            return True

        if existing["status"] == "PROCESSED":
            return False  # Already processed!

        # Retry attempt for RECEIVED or FAILED status
        upd = (
            update(inbox_messages)
            .where(
                inbox_messages.c.message_id == message_id,
                inbox_messages.c.consumer_name == consumer_name,
            )
            .values(
                attempt_count=inbox_messages.c.attempt_count + 1,
                status="RECEIVED",
            )
        )
        await self._session.execute(upd)
        return True

    async def mark_processed(
        self, *, message_id: str, consumer_name: str, now: datetime
    ) -> None:
        """Mark an inbox message as successfully processed."""
        stmt = (
            update(inbox_messages)
            .where(
                inbox_messages.c.message_id == message_id,
                inbox_messages.c.consumer_name == consumer_name,
            )
            .values(status="PROCESSED", processed_at=now)
        )
        await self._session.execute(stmt)

    async def record_failure(
        self, *, message_id: str, consumer_name: str, error: str, now: datetime
    ) -> None:
        """Record processing failure on an inbox message."""
        stmt = (
            update(inbox_messages)
            .where(
                inbox_messages.c.message_id == message_id,
                inbox_messages.c.consumer_name == consumer_name,
            )
            .values(status="FAILED", last_error=error[:2000])
        )
        await self._session.execute(stmt)


__all__ = ["SqlAlchemyInboxRepository"]
